#include "filsys/Root.h"

using namespace rookxx::filsys;

#pragma region init

Root::Root()
{
}

Root::Root(const rookxx::ramen::String16& name)
{
}

Root::Root(rookxx::ramen::String16&& name)
{
}

Root::Root(const rookxx::ramen::String16& name, FSType type)
{
}

Root::Root(rookxx::ramen::String16&& name, FSType type)
{
}

Root::~Root()
{
}

Root::Root(Root&& src)
{
}

Root& Root::operator=(Root&& src)
{
}

#pragma endregio

#pragma region properties

bool Root::isRoot() const { return true; }

bool Root::isValid() const { return f_IsValid; }

const rookxx::ramen::String16& Root::name() const { return f_Name; }

#pragma endregion

#pragma region helper

void Root::m_SetName(const rookxx::ramen::String16& src)
{
}

void Root::m_SetName(rookxx::ramen::String16&& src)
{
}

#pragma endregion