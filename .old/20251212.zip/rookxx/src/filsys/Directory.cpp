#include "filsys/Directory.h"

using namespace rookxx::filsys;

#pragma region init

Directory::Directory()
{
}

Directory::Directory(FSType type)
{
}

Directory::~Directory()
{
}

Directory::Directory(Directory&& src)
{
}

Directory& Directory::operator=(Directory&& src)
{
}

#pragma endregion

#pragma region properties

bool Directory::isFile() const { return false; }

bool Directory::isDirectory() const { return true; }

#pragma endregion

#pragma region helper

void Directory::m_Remove(Node** ptr)
{
}

void Directory::m_Reorder()
{
}

bool Directory::m_NameExists(const rookxx::ramen::String16& name)
{
}

#pragma endregion