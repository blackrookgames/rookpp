#include "filsys/File.h"

using namespace rookxx::filsys;

#pragma region init

File::File()
{
}

File::File(const rookxx::ramen::String16& name)
{
}

File::File(rookxx::ramen::String16&& name)
{
}

File::File(const rookxx::ramen::String16& name, FSType type)
{
}

File::File(rookxx::ramen::String16&& name, FSType type)
{
}

File::~File()
{
}

File::File(File&& src)
{
}

File& File::operator=(File&& src)
{
}

#pragma endregion

#pragma region properties

bool File::isFile() const { return true; }

bool File::isDirectory() const { return false; }

bool File::isRoot() const { return false; }

bool File::isValid() const { return f_IsValid; }

const rookxx::ramen::String16& File::name() const { return f_Name; }

#pragma endregion

#pragma region helper

void File::m_SetName(const rookxx::ramen::String16& src)
{
}

void File::m_SetName(rookxx::ramen::String16&& src)
{
}

#pragma endregion