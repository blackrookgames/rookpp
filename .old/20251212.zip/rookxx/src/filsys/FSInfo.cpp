#include "filsys/FSInfo.h"

using namespace rookxx::filsys;

#pragma region static

#ifdef __OS_WIN32__

const FSType FSInfo::os = FSType::Windows;

#else
#ifdef __OS_UNIX__

const FSType FSInfo::os = FSType::Unix;

#else

const FSType FSInfo::os = FSType::Unknown;

#endif
#endif

#pragma endregion