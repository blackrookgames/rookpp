#include "filsys/Node.h"

#include "filsys/FSInfo.h"
#include "filsys/Directory.h"

using namespace rookxx::filsys;

#pragma region init

Node::Node() : Node(FSType::Unknown)
{ }

Node::Node(FSType type)
{
    f_Deleting = false;
    f_Type = type;
    f_Parent = nullptr;
    f_Ptr = nullptr;
}

Node::~Node()
{
    if (f_Deleting) return;
    f_Deleting = true;
    m_Reset();
}

Node::Node(Node&& src)
{
    m_MoveFrom(std::move(src));
}

Node& Node::operator=(Node&& src)
{
    if (this != &src)
    {
        m_Reset();
        m_MoveFrom(std::move(src));
    }
    return *this;
}

void Node::m_BadAssign()
{
    f_Deleting = false;
    f_Type = FSType::Unknown;
    f_Parent = nullptr;
    f_Ptr = nullptr;
}

void Node::m_Reset()
{
    // Remove from parent
    if (f_Parent && (!f_Parent->f_Deleting))
        f_Parent->m_Remove(f_Ptr);
}

void Node::m_MoveFrom(Node&& src)
{
    if (!src.f_Deleting)
    {
        f_Deleting = false;
        f_Type = src.f_Type;
        f_Parent = src.f_Parent;
        f_Ptr = src.f_Ptr;
        src.f_Type = FSType::Unknown;
        src.f_Parent = nullptr;
        src.f_Ptr = nullptr;
    }
    else
    {
        m_BadAssign();
    }
}

#pragma endregion

#pragma region properties

FSType Node::type() const { return f_Type; }

Directory* Node::parent() { return f_Parent; }
const Directory* Node::parent() const { return f_Parent; }

#pragma endregion

#pragma region helper

bool Node::p_Deleting() const { return f_Deleting; }

#pragma endregion

#pragma region functions

bool Node::rename(const rookxx::ramen::String16& name)
{
    // Check if name is already taken
    if (f_Parent && (!f_Parent->m_NameExists(name)))
        return false;
    // Rename
    m_SetName(name);
    // Update parent
    if (f_Parent)
        f_Parent->m_Reorder();
    // Success!!!
    return true;
}

bool Node::rename(rookxx::ramen::String16&& name)
{
    // Check if name is already taken
    if (f_Parent && (!f_Parent->m_NameExists(name)))
        return false;
    // Rename
    m_SetName(std::move(name));
    // Update parent
    if (f_Parent)
        f_Parent->m_Reorder();
    // Success!!!
    return true;
}

#pragma endregion