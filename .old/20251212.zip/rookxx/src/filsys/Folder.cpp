#include "filsys/Folder.h"

using namespace rookxx::filsys;

#pragma region init

Folder::Folder()
{
}

Folder::Folder(const rookxx::ramen::String16& name)
{
}

Folder::Folder(rookxx::ramen::String16&& name)
{
}

Folder::Folder(const rookxx::ramen::String16& name, FSType type)
{
}

Folder::Folder(rookxx::ramen::String16&& name, FSType type)
{
}

Folder::~Folder()
{
}

Folder::Folder(Folder&& src)
{
}

Folder& Folder::operator=(Folder&& src)
{
}

#pragma endregion

#pragma region properties

bool Folder::isRoot() const { return false; }

bool Folder::isValid() const { return f_IsValid; }

const rookxx::ramen::String16& Folder::name() const { return f_Name; }

#pragma endregion

#pragma region helper

void Folder::m_SetName(const rookxx::ramen::String16& src)
{
}

void Folder::m_SetName(rookxx::ramen::String16&& src)
{
}

#pragma endregion