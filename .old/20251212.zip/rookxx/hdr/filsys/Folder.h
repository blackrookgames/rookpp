#include "filsys/Directory.h"

#ifndef rookxx_filsys_Folder_h
#define rookxx_filsys_Folder_h

namespace rookxx::filsys
{
    /// @brief Represents a file system folder
    class Folder : public Directory
    {
        #pragma region init

    public:

        /// @brief Empty constructor for Folder
        /// @note The file system type will be the same as the file system type of the operating system
        Folder();

        /// @brief Constructor for Folder
        /// @param name Name of folder
        /// @note The file system type will be the same as the file system type of the operating system
        Folder(const rookxx::ramen::String16& name);

        /// @brief Constructor for Folder
        /// @param name Name of folder
        /// @note The file system type will be the same as the file system type of the operating system
        Folder(rookxx::ramen::String16&& name);

        /// @brief Constructor for Folder
        /// @param name Name of folder
        /// @param type Folder system type
        Folder(const rookxx::ramen::String16& name, FSType type);

        /// @brief Constructor for Folder
        /// @param name Name of folder
        /// @param type Folder system type
        Folder(rookxx::ramen::String16&& name, FSType type);
        
        /// @brief Destructor for Folder
        virtual ~Folder();

        /// @brief Move constructor for Folder
        /// @param src Source
        Folder(Folder&& src);

        /// @brief Move assignment for Folder
        /// @param src Source
        Folder& operator=(Folder&& src);
        
        // We won't need these
        Folder(const Folder& src) = delete;
        Folder& operator=(const Folder& src) = delete;

        #pragma endregion

        #pragma region fields

    private:
    
        rookxx::ramen::String16 f_Name;
        bool f_IsValid;

        #pragma endregion

        #pragma region properties

    public:

        /// @brief Whether or not the node is a root directory
        /// @note For Folder, this will always return false
        bool isRoot() const override;

        /// @brief Whether or not the name is valid 
        bool isValid() const override;

        /// @brief Name
        const rookxx::ramen::String16& name() const override;

        #pragma endregion

        #pragma region helper

    protected:

        void m_SetName(const rookxx::ramen::String16& src) override;

        void m_SetName(rookxx::ramen::String16&& src) override;

        #pragma endregion
    };
}

#endif