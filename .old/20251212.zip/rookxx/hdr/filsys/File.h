#include <cstddef>
#include <cstdint>
#include "filsys/Node.h"

#ifndef rookxx_filsys_File_h
#define rookxx_filsys_File_h

namespace rookxx::filsys
{
    /// @brief Represents a file within a file system
    class File : public Node
    {
        #pragma region init

    public:

        /// @brief Empty constructor for File
        /// @note The file system type will be the same as the file system type of the operating system
        File();

        /// @brief Constructor for File
        /// @param name Name of file
        /// @note The file system type will be the same as the file system type of the operating system
        File(const rookxx::ramen::String16& name);

        /// @brief Constructor for File
        /// @param name Name of file
        /// @note The file system type will be the same as the file system type of the operating system
        File(rookxx::ramen::String16&& name);

        /// @brief Constructor for File
        /// @param name Name of file
        /// @param type File system type
        File(const rookxx::ramen::String16& name, FSType type);

        /// @brief Constructor for File
        /// @param name Name of file
        /// @param type File system type
        File(rookxx::ramen::String16&& name, FSType type);
        
        /// @brief Destructor for File
        virtual ~File();

        /// @brief Move constructor for File
        /// @param src Source
        File(File&& src);

        /// @brief Move assignment for File
        /// @param src Source
        File& operator=(File&& src);
        
        // We won't need these
        File(const File& src) = delete;
        File& operator=(const File& src) = delete;

        #pragma endregion

        #pragma region fields

    private:
    
        rookxx::ramen::String16 f_Name;
        bool f_IsValid;

        #pragma endregion

        #pragma region properties

    public:

        /// @brief Whether or not the node is a file
        /// @note For File, this will always return true
        bool isFile() const override;

        /// @brief Whether or not the node is a directory
        /// @note For File, this will always return false
        bool isDirectory() const override;

        /// @brief Whether or not the node is a root directory
        /// @note For File, this will always return false
        bool isRoot() const override;

        /// @brief Whether or not the name is valid 
        bool isValid() const override;

        /// @brief Name
        const rookxx::ramen::String16& name() const override;

        #pragma endregion

        #pragma region helper

    protected:

        void m_SetName(const rookxx::ramen::String16& src) override;

        void m_SetName(rookxx::ramen::String16&& src) override;

        #pragma endregion
    };
}

#endif