#include <cstddef>
#include <cstdint>
#include "filsys/FSType.h"

#ifndef rookxx_filsys_FSInfo_h
#define rookxx_filsys_FSInfo_h

namespace rookxx::filsys
{
    /// @brief Represents information about a file system
    class FSInfo
    {
        #pragma region static

        /// @brief The type of file system that exists on the operating system
        public: static const FSType os;

        #pragma endregion
    };
}

#endif