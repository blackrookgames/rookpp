#include <cstddef>
#include <cstdint>

#ifndef rookxx_filsys_FSType_h
#define rookxx_filsys_FSType_h

namespace rookxx::filsys
{
    /// @brief Represents a type of file system
    enum struct FSType
    {
        /// @brief Unknown file system
        Unknown = 0,
        /// @brief Windows file system
        Windows,
        /// @brief Unix file system
        Unix,
    };
}

#endif