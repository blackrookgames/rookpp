#include <cstddef>
#include <cstdint>
#include "filsys/FSType.h"
#include "ramen/String16.h"

#ifndef rookxx_filsys_Node_h
#define rookxx_filsys_Node_h

namespace rookxx::filsys
{
#ifndef rookxx_filsys_Directory_h
    class Directory;
#endif

    /// @brief Represents a file or directory within a file system
    class Node
    {
        #pragma region init

    public:

        /// @brief Empty constructor for Node
        /// @note The file system type will be the same as the file system type of the operating system
        Node();

        /// @brief Constructor for Node
        /// @param type File system type
        Node(FSType type);
        
        /// @brief Destructor for Node
        virtual ~Node();

        /// @brief Move constructor for Node
        /// @param src Source
        Node(Node&& src);

        /// @brief Move assignment for Node
        /// @param src Source
        Node& operator=(Node&& src);
        
        // We won't need these
        Node(const Node& src) = delete;
        Node& operator=(const Node& src) = delete;

    private:

        void m_BadAssign(); // Just in case a node that's in the middle of deleting is assigned

        void m_Reset();

        // Assume f_Parent is nullptr
        // Assume f_Ptr is nullptr
        void m_MoveFrom(Node&& src);

        #pragma endregion

        #pragma region friends

        friend Directory;

        #pragma endregion

        #pragma region fields

    private:

        bool f_Deleting;

        FSType f_Type;
        
        // Also accessed also modified by Directory
        Directory* f_Parent;
        // Also accessed also modified by Directory
        Node** f_Ptr; // This is the place where the parent is storing the reference to this

        #pragma endregion

        #pragma region properties

    public:

        /// @brief Whether or not the node is a file
        virtual bool isFile() const = 0;

        /// @brief Whether or not the node is a directory
        virtual bool isDirectory() const = 0;

        /// @brief Whether or not the node is a root directory
        virtual bool isRoot() const = 0;

        /// @brief Whether or not the name is valid 
        virtual bool isValid() const = 0;

        /// @brief Name
        virtual const rookxx::ramen::String16& name() const = 0;

        /// @brief File system type
        FSType type() const;

        /// @brief Parent directory
        Directory* parent();
        /// @brief Parent directory
        const Directory* parent() const;

        #pragma endregion

        #pragma region helper

    protected:

        bool p_Deleting() const;

        virtual void m_SetName(const rookxx::ramen::String16& src) = 0;

        virtual void m_SetName(rookxx::ramen::String16&& src) = 0;

        #pragma endregion

        #pragma region functions

    public:
        
        /// @brief Attempts to rename the node
        /// @param name New name for node
        /// @return True if successfully renamed; false if another node in the parent directory has the specified name
        /// @note A returned value of true does not neccessarily mean the new name is valid. 
        /// Use isValid() to be sure the new name is valid.
        bool rename(const rookxx::ramen::String16& name);
        
        /// @brief Attempts to rename the node
        /// @param name New name for node
        /// @return True if successfully renamed; false if another node in the parent directory has the specified name
        /// @note A returned value of true does not neccessarily mean the new name is valid. 
        /// Use isValid() to be sure the new name is valid.
        bool rename(rookxx::ramen::String16&& name);

        #pragma endregion
    };
}

#endif