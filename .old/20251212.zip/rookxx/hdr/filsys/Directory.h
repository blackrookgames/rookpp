#include "filsys/Node.h"

#ifndef rookxx_filsys_Directory_h
#define rookxx_filsys_Directory_h

namespace rookxx::filsys
{
    /// @brief Represents a file system directory
    class Directory : public Node
    {
        #pragma region init

    public:

        /// @brief Empty constructor for Directory
        /// @note The file system type will be the same as the file system type of the operating system
        Directory();

        /// @brief Constructor for Directory
        /// @param type File system type
        Directory(FSType type);
        
        /// @brief Destructor for Directory
        virtual ~Directory();

        /// @brief Move constructor for Directory
        /// @param src Source
        Directory(Directory&& src);

        /// @brief Move assignment for Directory
        /// @param src Source
        Directory& operator=(Directory&& src);

        // We won't need these
        Directory(const Directory& src) = delete;
        Directory& operator=(const Directory& src) = delete;

        #pragma endregion

        #pragma region friends

        friend Node;

        #pragma endregion

        #pragma region properties

    public:

        /// @brief Whether or not the node is a file
        /// @note For Directory, this will always return false
        bool isFile() const override;

        /// @brief Whether or not the node is a directory
        /// @note For Directory, this will always return true
        bool isDirectory() const override;

        #pragma endregion

        #pragma region helper
    
    private:

        // Assume ptr refers to a valid location
        // Also accessed by Node
        void m_Remove(Node** ptr);

        // Also accessed by Node
        void m_Reorder();

        // Also accessed by Node
        bool m_NameExists(const rookxx::ramen::String16& name);

        #pragma endregion
    };
}

#endif